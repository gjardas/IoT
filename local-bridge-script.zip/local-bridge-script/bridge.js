const admin = require("firebase-admin");
const axios = require("axios");

const SERVICE_ACCOUNT_FILE =
  "./mottu-e25a9-firebase-adminsdk-fbsvc-1493cc86bd.json";

const FIREBASE_DB_URL = "https://mottu-e25a9-default-rtdb.firebaseio.com";

const JAVA_API_ENDPOINT = "http://localhost:8080/api/movimentacoes";

const SUA_API_KEY = "HlqyN5CN0oWvjaD82XPpr0tPvmSXrWyQ";

try {
  const serviceAccount = require(SERVICE_ACCOUNT_FILE);
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    databaseURL: FIREBASE_DB_URL,
  });
} catch (e) {
  console.error(
    "ERRO: Não foi possível encontrar o arquivo da Service Account!"
  );
  console.error(
    `Verifique se o arquivo "${SERVICE_ACCOUNT_FILE}" está na mesma pasta.`
  );
  process.exit(1);
}

const ref = admin.database().ref("/movimento");

console.log("===================================");
console.log("PONTE (Node.js) INICIADA");
console.log(`Ouvindo o Firebase em: ${FIREBASE_DB_URL}/movimento.json`);
console.log(`Encaminhando para a API Java em: ${JAVA_API_ENDPOINT}`);
console.log("===================================");
console.log("Aguardando dados do Wokwi...");

ref.on("child_added", async (snapshot) => {
  const iotData = snapshot.val();
  const pushId = snapshot.key;

  console.log("\n--- NOVO EVENTO RECEBIDO ---");
  console.log("Dado Bruto do Wokwi:", iotData);

  if (iotData.status !== "entrada" && iotData.status !== "saida") {
    console.log(`Evento ignorado (status: ${iotData.status}).`);
    return;
  }

  const cleanRfid = iotData.id.replace(/\s/g, "");
  const payloadParaJava = {
    rfid: cleanRfid,
    sensorCodigo: iotData.vaga,
  };

  console.log("Enviando para a API Java:", payloadParaJava);

  try {
    const response = await axios.post(JAVA_API_ENDPOINT, payloadParaJava, {
      headers: {
        "Content-Type": "application/json",
        "X-API-KEY": SUA_API_KEY,
      },
    });

    console.log(`SUCESSO! API Java respondeu com status: ${response.status}`);

    await snapshot.ref.remove();
    console.log(`Evento ${pushId} processado e removido da fila.`);
  } catch (error) {
    console.error("ERRO GRAVE: Falha ao enviar dados para a API Java!");
    if (error.response) {
      console.error("Dados do Erro:", error.response.data);
    } else {
      console.error("Mensagem:", error.message);
    }
  }
});
